using HarmonyLib;
using Reactor.Utilities;

namespace SafeRoomMod.Patches;

/// <summary>
/// Ponto central da mod: intercepta a checagem de assassinato ANTES dela
/// acontecer. Se a vítima estiver dentro da sala que ela escolheu, o kill é
/// cancelado (retornamos false pro Harmony pular o método original).
///
/// Como o mod é host-only, essa checagem só roda no cliente do host — e é
/// o host quem manda a RPC de morte pra todo mundo. Cancelando aqui, a RPC
/// nunca chega a ser enviada, então o efeito vale pra sala inteira, com ou
/// sem o mod instalado.
///
/// TODO: confirme o nome exato do método na versão atual do jogo — em
/// builds recentes pode ser PlayerControl.CheckMurder ou
/// PlayerControl.MurderPlayer dependendo da versão. Veja o código de
/// TownOfHost / TOU-Mira como referência.
/// </summary>
[HarmonyPatch(typeof(PlayerControl), nameof(PlayerControl.CheckMurder))]
public static class MurderPatch
{
    public static bool Prefix(PlayerControl __instance, PlayerControl target)
    {
        if (!AmongUsClient.Instance.AmHost)
        {
            // Em cliente não-host isso nunca deveria nem rodar, mas por
            // segurança deixamos o comportamento original passar.
            return true;
        }

        if (target == null)
        {
            return true;
        }

        var pos = target.GetTruePosition();
        bool isSafe = SafeRoomManager.IsPlayerSafe(target.PlayerId, pos.x, pos.y);

        if (isSafe)
        {
            Log.LogMessage($"Kill bloqueado: {target.Data?.PlayerName} estava na sala segura dele.");
            return false; // cancela o kill
        }

        return true; // deixa o kill acontecer normalmente
    }
}
