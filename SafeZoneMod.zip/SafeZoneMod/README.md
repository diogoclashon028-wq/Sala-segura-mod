# Safe Zone Mod

Mod pra Among Us (MiraAPI + BepInEx) que cria uma área no mapa onde ninguém
pode ser morto. Dá pra configurar tempo máximo de permanência também.

## Estrutura

- `Managers/SafeZoneManager.cs` - guarda quem tá protegido e desde quando
- `Components/SafeZoneTrigger.cs` - collider 2D em modo trigger, detecta
  entrada/saída de player na área
- `Patches/PlayerControlPatches.cs` - bloqueia o kill via Harmony
- `Patches/ShipStatusPatches.cs` - sobe a zona quando o mapa carrega

## Antes de compilar isso

- **a posição da zona tá hardcoded em (0,0,0)**, é só placeholder mesmo.
  Vai lá em `ShipStatusPatches.Begin_Postfix` e troca pelas coordenadas do
  ponto que você quer proteger. Pra descobrir a posição, anda até o local no
  jogo e loga `PlayerControl.LocalPlayer.transform.position`.
- confere se o `NuGet.config` tá apontando pro feed certo (BepInEx/AllOfUs),
  senão o `AmongUs.GameLibs.Steam` não resolve
- fixei a MiraAPI em `0.4.1` - antes de subir pra valer, vale checar se saiu
  versão nova, principalmente a parte de opções de menu que muda toda hora

## Build

Net 6, AnyCPU, build única serve pra PC e Android:

```
dotnet build -c Release
```

sai em `bin/Release/net6.0/SafeZoneMod.dll`

## Portando pra Starlight

Segui o guia oficial deles (allofus.dev/guides/starlight-dev-guide). Pontos
que já tratei aqui:

- não uso path do Windows em lugar nenhum, e não gravo nada em disco por
  enquanto - se for adicionar isso depois, usa `Application.persistentDataPath`,
  NUNCA `Paths.GameRootPath` (não é gravável na Starlight)
- não uso asset bundle, então não precisa rebuildar nada pro Android
- não usei `#if ANDROID` em lugar nenhum porque não bati em nenhum método que
  só existe no PC. Se você adicionar algo e o build Android reclamar de
  método faltando, troca pro pacote `AmongUs.GameLibs.Android` temporariamente
  pra achar o erro antes de mandar pro celular

**Testar:** a Starlight pública não carrega mod não aprovado. Ou manda build
de teste pro time da AOU aprovar, ou entra no Beta Tester deles. Os dois
passam pelo Discord: discord.gg/FYYqJU2bvp

**Antes de publicar, testa:**
- em device Android de verdade, não só emulador
- se `CheckMurder` não tá sendo inlinado no Android (IL2CPP Usage Analyzer,
  allofus.dev/il2cpp.html) - se estiver, o `MurderPlayer` ainda segura o
  bloqueio, só perde o feedback instantâneo
- múltiplos players entrando/saindo da zona ao mesmo tempo
- host saindo com gente dentro da zona

## Config

Fica em `BepInEx/config/com.seunome.safezonemod.cfg`:

| opção | padrão | o que faz |
|---|---|---|
| Ativar Zona Segura | true | liga/desliga tudo |
| Raio da Zona | 2.5 | unidade do Unity, ajusta no olho testando |
| Tempo max de permanência | 15s | 0 = sem limite |

Se quiser essas opções aparecendo no menu do lobby em vez de só no arquivo
`.cfg`, dá pra migrar pra API de opções da própria MiraAPI - só olha a
documentação atual deles antes (github.com/All-Of-Us-Mods/MiraAPI), a classe
de opção muda de nome com uma frequência meio chata.

## TODO

- [ ] testar em mapa Airship (tem mais de um nível de altura, o trigger 2D
  pode se comportar estranho ali)
