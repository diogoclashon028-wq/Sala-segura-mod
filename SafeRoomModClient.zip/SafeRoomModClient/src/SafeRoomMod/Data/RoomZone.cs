namespace SafeRoomMod.Data;

/// <summary>
/// Retângulo que define os limites de uma sala no mapa, em coordenadas de
/// jogo (as mesmas usadas pela posição do PlayerControl).
/// </summary>
public readonly struct RoomZone
{
    public readonly string Name;
    public readonly float MinX;
    public readonly float MinY;
    public readonly float MaxX;
    public readonly float MaxY;

    public RoomZone(string name, float minX, float minY, float maxX, float maxY)
    {
        Name = name;
        MinX = minX;
        MinY = minY;
        MaxX = maxX;
        MaxY = maxY;
    }

    public bool Contains(float x, float y)
    {
        return x >= MinX && x <= MaxX && y >= MinY && y <= MaxY;
    }
}
