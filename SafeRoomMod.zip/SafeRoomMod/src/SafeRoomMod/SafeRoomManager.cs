using System.Collections.Concurrent;
using Impostor.Api.Games;
using Impostor.Api.Innersloth;
using SafeRoomMod.Data;

namespace SafeRoomMod;

/// <summary>
/// Guarda, para cada partida (IGame) e cada jogador (byte = PlayerId),
/// qual sala segura foi escolhida, e se a fase de seleção ainda
/// está aberta.
///
/// Tudo aqui vive apenas em memória do servidor — nada é enviado
/// ao cliente além de mensagens de chat, então não é necessário
/// nenhum mod no APK do Android.
/// </summary>
public class SafeRoomManager
{
    private readonly ConcurrentDictionary<IGame, GameState> _games = new();

    public GameState GetOrCreateGameState(IGame game)
    {
        return _games.GetOrAdd(game, _ => new GameState());
    }

    public void RemoveGame(IGame game)
    {
        _games.TryRemove(game, out _);
    }

    public class GameState
    {
        /// <summary>Se true, jogadores ainda podem escolher/trocar de sala.</summary>
        public bool SelectionPhaseOpen { get; set; } = true;

        /// <summary>PlayerId -> sala escolhida.</summary>
        public ConcurrentDictionary<byte, RoomZone> SelectedRooms { get; } = new();

        public void SetRoom(byte playerId, RoomZone room)
        {
            SelectedRooms[playerId] = room;
        }

        public RoomZone? GetRoom(byte playerId)
        {
            return SelectedRooms.TryGetValue(playerId, out var room) ? room : null;
        }
    }
}
