using HarmonyLib;
using Reactor.Utilities;
using Reactor.Utilities.Extensions;
using UnityEngine;

namespace SafeRoomMod.Patches;

/// <summary>
/// Quando a partida começa, abre uma janela de N segundos onde cada jogador
/// pode "reivindicar" a sala em que está parado como sua sala segura
/// (usando o botão customizado, ver UI/ClaimRoomButton.cs).
///
/// TODO: confirme se PlayerControl.Start() é realmente o gancho certo pra
/// "início da partida" na versão atual do jogo — em algumas versões faz
/// mais sentido usar IntroCutscene.Begin ou GameStartManager.
/// </summary>
[HarmonyPatch(typeof(PlayerControl), nameof(PlayerControl.Start))]
public static class GameStartPatch
{
    private const float SelectionWindowSeconds = 20f;

    public static void Postfix(PlayerControl __instance)
    {
        if (!__instance.AmOwner || !AmongUsClient.Instance.AmHost)
        {
            return;
        }

        SafeRoomManager.Reset();
        SafeRoomManager.SelectionPhaseOpen = true;

        Coroutines.Start(CloseSelectionAfterDelay());
    }

    private static System.Collections.IEnumerator CloseSelectionAfterDelay()
    {
        yield return new WaitForSeconds(SelectionWindowSeconds);
        SafeRoomManager.SelectionPhaseOpen = false;
    }
}
