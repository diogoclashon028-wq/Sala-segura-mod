using Impostor.Api.Events.Managers;
using Impostor.Api.Plugins;
using Microsoft.Extensions.Logging;

namespace SafeRoomMod;

[ImpostorPlugin(
    package: "com.seuservidor.saferoom",
    name: "SafeRoomMod",
    author: "SeuNome",
    version: "1.0.0")]
public class SafeRoomPlugin : PluginBase
{
    private readonly IEventManager _eventManager;
    private readonly ILogger<SafeRoomPlugin> _logger;
    private readonly SafeRoomManager _manager;

    private IDisposable? _unregister;

    public SafeRoomPlugin(IEventManager eventManager, ILogger<SafeRoomPlugin> logger)
    {
        _eventManager = eventManager;
        _logger = logger;
        _manager = new SafeRoomManager();
    }

    public override ValueTask EnableAsync()
    {
        _logger.LogInformation("SafeRoomMod habilitado.");

        // Se sua versão do Impostor suportar injeção de dependência
        // para listeners, prefira registrar via DI container do host.
        // Aqui, criamos manualmente por simplicidade do esqueleto.
        var listener = new SafeRoomEventListener(_manager, LoggerFactoryPlaceholder());
        _unregister = _eventManager.RegisterListener(listener);

        return default;
    }

    public override ValueTask DisableAsync()
    {
        _logger.LogInformation("SafeRoomMod desabilitado.");
        _unregister?.Dispose();
        return default;
    }

    private ILogger<SafeRoomEventListener> LoggerFactoryPlaceholder()
    {
        // TODO: troque por injeção real de ILogger<SafeRoomEventListener>
        // via construtor, assim que confirmar como o host do Impostor
        // resolve dependências dos plugins na sua versão.
        using var factory = LoggerFactory.Create(builder => builder.AddConsole());
        return factory.CreateLogger<SafeRoomEventListener>();
    }
}
