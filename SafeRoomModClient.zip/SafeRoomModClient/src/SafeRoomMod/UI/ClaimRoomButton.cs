using SafeRoomMod.Data;

namespace SafeRoomMod.UI;

/// <summary>
/// Lógica do botão "Reivindicar Sala". A ideia: o jogador anda até a sala
/// que quer proteger e aperta o botão durante a fase de seleção.
///
/// TODO: este arquivo mostra APENAS a lógica de decisão (qual sala está o
/// jogador, se pode reivindicar). A parte de registrar isso como um botão
/// visível na tela (ícone, HUD, hotkey) usa a API de Custom Buttons do
/// MiraAPI — a forma exata de registrar muda entre versões do MiraAPI,
/// então siga o "Custom Buttons" do repositório oficial (ExampleMod) pra
/// plugar esta função num botão real.
/// </summary>
public static class ClaimRoomLogic
{
    public static bool TryClaimCurrentRoom(PlayerControl player, byte mapId)
    {
        if (!SafeRoomManager.SelectionPhaseOpen)
        {
            return false;
        }

        if (!MapRooms.Rooms.TryGetValue(mapId, out var rooms))
        {
            return false;
        }

        var pos = player.GetTruePosition();

        foreach (var room in rooms)
        {
            if (room.Contains(pos.x, pos.y))
            {
                return SafeRoomManager.TryClaim(player.PlayerId, room);
            }
        }

        return false; // jogador não está em nenhuma sala reconhecida
    }
}
