using Impostor.Api.Events;
using Impostor.Api.Events.Player;
using Impostor.Api.Games;
using Microsoft.Extensions.Logging;
using SafeRoomMod.Data;

namespace SafeRoomMod;

/// <summary>
/// NOTA IMPORTANTE SOBRE A API:
/// Os nomes exatos das interfaces de evento (IPlayerChatEvent,
/// IPlayerKillEvent, IGameStartedEvent, etc.) podem variar
/// ligeiramente entre versões do pacote Impostor.Api. Confira os
/// eventos disponíveis em:
///   https://github.com/Impostor/Impostor/tree/master/src/Impostor.Api/Events
/// e ajuste as assinaturas abaixo para bater com a versão que você
/// referenciou no .csproj. A lógica (o "o quê" e "quando") permanece
/// a mesma — só os nomes de tipos podem precisar de pequenos ajustes.
/// </summary>
public class SafeRoomEventListener : IEventListener
{
    private const int SelectionPhaseSeconds = 20;

    private readonly SafeRoomManager _manager;
    private readonly ILogger<SafeRoomEventListener> _logger;

    public SafeRoomEventListener(SafeRoomManager manager, ILogger<SafeRoomEventListener> logger)
    {
        _manager = manager;
        _logger = logger;
    }

    /// <summary>
    /// Disparado quando a partida começa (após a tela de
    /// Impostor/Tripulante). Abre a fase de seleção e agenda o
    /// fechamento automático depois de alguns segundos.
    /// </summary>
    [EventListener]
    public void OnGameStarted(IGameStartedEvent e)
    {
        var state = _manager.GetOrCreateGameState(e.Game);
        state.SelectionPhaseOpen = true;
        state.SelectedRooms.Clear();

        BroadcastMessage(e.Game,
            $"[SalaSegura] Escolha sua sala com /sala <nome> em até {SelectionPhaseSeconds}s!");

        _ = CloseSelectionPhaseAfterDelay(e.Game, state);
    }

    private async Task CloseSelectionPhaseAfterDelay(IGame game, SafeRoomManager.GameState state)
    {
        await Task.Delay(TimeSpan.FromSeconds(SelectionPhaseSeconds));
        state.SelectionPhaseOpen = false;
        BroadcastMessage(game, "[SalaSegura] Fase de escolha encerrada!");
    }

    /// <summary>
    /// Disparado quando o jogo termina / lobby é desfeito.
    /// Limpa o estado guardado para não vazar memória.
    /// </summary>
    [EventListener]
    public void OnGameEnded(IGameEndedEvent e)
    {
        _manager.RemoveGame(e.Game);
    }

    /// <summary>
    /// Intercepta mensagens de chat para processar o comando
    /// "/sala NomeDaSala". Cancela a mensagem para que ela não
    /// apareça no chat de todo mundo.
    /// </summary>
    [EventListener]
    public void OnPlayerChat(IPlayerChatEvent e)
    {
        var message = e.Message.Trim();

        if (!message.StartsWith("/sala", StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        e.IsCancelled = true;

        var state = _manager.GetOrCreateGameState(e.Game);

        if (!state.SelectionPhaseOpen)
        {
            SendPrivateMessage(e.ClientPlayer, "[SalaSegura] A fase de escolha já encerrou.");
            return;
        }

        var parts = message.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length < 2)
        {
            SendPrivateMessage(e.ClientPlayer, "[SalaSegura] Uso: /sala NomeDaSala");
            return;
        }

        var roomName = parts[1].Trim();
        var mapType = e.Game.Options.Map;
        var room = MapRooms.FindRoom(mapType, roomName);

        if (room is null)
        {
            var disponiveis = string.Join(", ", MapRooms.GetRoomsForMap(mapType).Select(r => r.Name));
            SendPrivateMessage(e.ClientPlayer,
                $"[SalaSegura] Sala inválida. Opções: {disponiveis}");
            return;
        }

        state.SetRoom(e.ClientPlayer.Character.PlayerId, room.Value);
        SendPrivateMessage(e.ClientPlayer, $"[SalaSegura] Sua sala segura agora é: {room.Value.Name}");
    }

    /// <summary>
    /// O coração do mod: intercepta a tentativa de abate e cancela
    /// se a vítima estiver dentro da sala que ela escolheu.
    /// </summary>
    [EventListener]
    public void OnPlayerKill(IPlayerKillEvent e)
    {
        var state = _manager.GetOrCreateGameState(e.Game);
        var victim = e.PlayerControl;

        var room = state.GetRoom(victim.PlayerId);
        if (room is null)
        {
            // Jogador não escolheu sala (ou perdeu a fase) -> sem proteção.
            return;
        }

        var position = victim.NetworkTransform.Position;

        if (room.Value.Contains(position.X, position.Y))
        {
            e.IsCancelled = true;
            _logger.LogInformation(
                "Kill bloqueado: {Victim} estava protegido em {Room}",
                victim.PlayerInfo.PlayerName, room.Value.Name);

            SendPrivateMessage(e.ClientPlayer, $"[SalaSegura] Abate bloqueado! A vítima estava em {room.Value.Name}.");
        }
    }

    private static void BroadcastMessage(IGame game, string text)
    {
        foreach (var player in game.Players)
        {
            SendPrivateMessage(player, text);
        }
    }

    private static void SendPrivateMessage(Impostor.Api.Innersloth.Custom.IClientPlayer? player, string text)
    {
        // Ajuste este método para a API real de envio de mensagens de
        // sistema/chat do Impostor na versão que você estiver usando
        // (geralmente algo como player.Character.SendChatToPlayerAsync
        // ou um serviço de "system message").
        // Deixado como TODO proposital para você conectar ao método certo.
    }
}
