# SafeRoomMod

Mod de "Sala Segura" para Among Us, rodando 100% no servidor via
[Impostor](https://github.com/Impostor/Impostor) (servidor privado
em C#). Como toda a lógica roda no servidor, jogadores de PC e
Android jogam juntos sem precisar de nenhuma modificação no APK.

## Mecânica

1. Ao iniciar a partida, cada jogador tem alguns segundos para
   escolher uma sala usando `/sala NomeDaSala` no chat.
2. Enquanto o Tripulante estiver dentro da sala escolhida, o
   servidor cancela qualquer tentativa de abate contra ele.
3. Fora da sala, ele pode ser morto normalmente.
4. As salas disponíveis mudam automaticamente conforme o mapa
   (Skeld, MIRA HQ, Polus, Airship, Fungle).

## Status do projeto / TODOs

Este repositório é um **esqueleto funcional** — a estrutura, os
eventos e a lógica estão todos implementados, mas restam 3 pontos
que dependem de dados/decisões específicas do seu servidor:

- [ ] **Coordenadas reais das salas** em `src/SafeRoomMod/Data/MapRooms.cs`.
      Só o mapa Skeld tem valores de exemplo; os demais estão com
      `0f, 0f, 0f, 0f` como placeholder. Recomenda-se extrair as
      coordenadas de mods open-source já existentes (ex: TownOfHost)
      ou logando a posição do jogador nas bordas de cada sala.
- [ ] **Nomes exatos dos eventos/tipos da Impostor.Api** na versão
      que você for usar (`IPlayerKillEvent`, `IPlayerChatEvent`,
      `IGameStartedEvent`, `IGameEndedEvent`). A API muda entre
      versões — confira em
      https://github.com/Impostor/Impostor/tree/master/src/Impostor.Api/Events
      e ajuste `SafeRoomEventListener.cs` se necessário.
- [ ] **Envio de mensagens privadas** (`SendPrivateMessage` em
      `SafeRoomEventListener.cs`) está com um corpo vazio de
      propósito — conecte ao método real de chat/mensagem de
      sistema do seu servidor Impostor.

## Estrutura

```
SafeRoomMod/
├── SafeRoomMod.sln
├── src/SafeRoomMod/
│   ├── SafeRoomMod.csproj
│   ├── SafeRoomPlugin.cs          # entry point do plugin
│   ├── SafeRoomEventListener.cs   # toda a lógica de eventos
│   ├── SafeRoomManager.cs         # estado por partida/jogador
│   └── Data/
│       ├── RoomZone.cs            # struct de área retangular
│       └── MapRooms.cs            # tabela de salas por mapa
```

## Build local (opcional, para testar)

Pré-requisitos: .NET 8 SDK.

```bash
cd src/SafeRoomMod
dotnet build
```

O `.dll` gerado em `bin/Debug/net8.0/` pode ser copiado manualmente
para a pasta `plugins/` de um servidor Impostor local, se quiser
testar sem Docker.

## Deploy gratuito (Fly.io)

**Importante:** Among Us usa UDP para o tráfego de partida. Serviços
como o Render **não suportam UDP** em serviços web públicos, então
o deploy lá falha ou não fica jogável mesmo se o build passar. Por
isso este projeto usa o [Fly.io](https://fly.io), que suporta UDP
no plano gratuito.

Passo a passo:

1. Instale o `flyctl`: https://fly.io/docs/hands-on/install-flyctl/
2. `fly auth login`
3. Na raiz do repositório: `fly launch --no-deploy`
   (ele detecta o `Dockerfile` e o `fly.toml` já incluídos aqui —
   confirme para usá-los, e escolha um nome único para o app).
4. Depois do primeiro deploy, veja o IP público:
   `fly ips list`
5. Configure esse IP no servidor:
   `fly secrets set IMPOSTOR_Server__PublicIp=SEU_IP_AQUI`
6. `fly deploy`

O arquivo `fly.toml` já expõe a porta UDP 22023 (jogo) e a porta
HTTP 22021 (descoberta do servidor pelo cliente).

Para conectar o Among Us (PC ou Android) a esse servidor, use o
gerador de arquivo de região em
https://impostor.github.io/Impostor/ apontando para o seu domínio
`.fly.dev` ou IP do Fly.io.

## Licença

Adicione a licença de sua preferência (ex: MIT) antes de publicar.
