# SafeRoomMod

Mod de "Sala Segura" para Among Us, rodando 100% no servidor via
[Impostor](https://github.com/Impostor/Impostor) (servidor privado
em C#). Como toda a lógica roda no servidor, jogadores de PC e
Android jogam juntos sem precisar de nenhuma modificação no APK.

## Mecânica

1. Ao iniciar a partida, cada jogador tem alguns segundos para
   escolher uma sala usando `/sala NomeDaSala` no chat.
2. Enquanto o Tripulante estiver dentro da sala escolhida, o
   servidor cancela qualquer tentativa de abate contra ele.
3. Fora da sala, ele pode ser morto normalmente.
4. As salas disponíveis mudam automaticamente conforme o mapa
   (Skeld, MIRA HQ, Polus, Airship, Fungle).

## Status do projeto / TODOs

Este repositório é um **esqueleto funcional** — a estrutura, os
eventos e a lógica estão todos implementados, mas restam 3 pontos
que dependem de dados/decisões específicas do seu servidor:

- [ ] **Coordenadas reais das salas** em `src/SafeRoomMod/Data/MapRooms.cs`.
      Só o mapa Skeld tem valores de exemplo; os demais estão com
      `0f, 0f, 0f, 0f` como placeholder. Recomenda-se extrair as
      coordenadas de mods open-source já existentes (ex: TownOfHost)
      ou logando a posição do jogador nas bordas de cada sala.
- [ ] **Nomes exatos dos eventos/tipos da Impostor.Api** na versão
      que você for usar (`IPlayerKillEvent`, `IPlayerChatEvent`,
      `IGameStartedEvent`, `IGameEndedEvent`). A API muda entre
      versões — confira em
      https://github.com/Impostor/Impostor/tree/master/src/Impostor.Api/Events
      e ajuste `SafeRoomEventListener.cs` se necessário.
- [ ] **Envio de mensagens privadas** (`SendPrivateMessage` em
      `SafeRoomEventListener.cs`) está com um corpo vazio de
      propósito — conecte ao método real de chat/mensagem de
      sistema do seu servidor Impostor.

## Estrutura

```
SafeRoomMod/
├── SafeRoomMod.sln
├── src/SafeRoomMod/
│   ├── SafeRoomMod.csproj
│   ├── SafeRoomPlugin.cs          # entry point do plugin
│   ├── SafeRoomEventListener.cs   # toda a lógica de eventos
│   ├── SafeRoomManager.cs         # estado por partida/jogador
│   └── Data/
│       ├── RoomZone.cs            # struct de área retangular
│       └── MapRooms.cs            # tabela de salas por mapa
```

## Build

Pré-requisitos: .NET 8 SDK.

```bash
cd src/SafeRoomMod
dotnet build
```

O `.dll` gerado em `bin/Debug/net8.0/` deve ser copiado para a
pasta de plugins do seu servidor Impostor (geralmente `plugins/`
na raiz onde está o binário do servidor).

## Licença

Adicione a licença de sua preferência (ex: MIT) antes de publicar.
