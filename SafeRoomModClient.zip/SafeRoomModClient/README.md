# Sala Segura — mod cliente (Starlight)

Versão reescrita do mod para rodar como **mod de cliente host-only**, usando
Reactor + MiraAPI, compatível com o Starlight (Android).

## Como funciona agora

- **Só quem hospeda a partida (host) precisa ter o mod instalado.**
  Jogadores sem o mod entram normalmente — o host que decide, nos
  bastidores, se um kill acontece ou não.
- No início da partida, abre uma janela de 20s onde cada jogador pode andar
  até uma sala e "reivindicá-la" como sua sala segura.
- Enquanto o jogador estiver fisicamente dentro da sala que reivindicou, o
  Impostor não consegue matá-lo.

## O que falta preencher (TODO)

1. **Coordenadas reais das salas** em `src/SafeRoomMod/Data/MapRooms.cs` —
   só o Skeld tem valores de exemplo; MiraHQ, Polus, Airship e Fungle estão
   com placeholders `(0,0,0,0)`.
2. **Conectar `ClaimRoomLogic` a um botão visível** na tela, usando a API de
   Custom Buttons do MiraAPI (o nome exato dos métodos muda entre versões —
   veja o ExampleMod oficial do MiraAPI no GitHub).
3. **Confirmar os nomes dos métodos do jogo** usados nos patches
   (`PlayerControl.CheckMurder`, `PlayerControl.Start`) — podem ter mudado
   de nome na versão atual do Among Us. Se o build falhar reclamando que
   esses métodos não existem, é o primeiro lugar pra olhar.

## Como compilar (você não precisa de PC — isso roda na nuvem)

1. Crie um repositório no GitHub (pode ser pelo próprio app do celular) e
   suba esta pasta inteira.
2. O arquivo `.github/workflows/build.yml` já está configurado: assim que
   você subir o código (ou disparar manualmente em **Actions →
   "Compilar Sala Segura" → Run workflow**), o GitHub compila tudo
   automaticamente num computador na nuvem — não precisa instalar nada no
   seu celular.
3. Quando o workflow terminar (ícone verde ✅), entre nele e baixe o
   artefato **SafeRoomMod** — vai ser um arquivo `SafeRoomMod.dll`.

## Como instalar no Starlight

1. Publique o `SafeRoomMod.dll` como um **Release** no seu repositório do
   GitHub (Releases → Create a new release → anexa o `.dll`).
2. No Starlight, use a opção de **instalar mod por link/URL** (usada por
   mods host-only como o Lotus) apontando pro link direto do `.dll` no seu
   Release.
3. Só você (o host) instala. Teste primeiro numa sala privada com amigos,
   um jogador com o mod e outro sem, pra confirmar que o kill é bloqueado
   pros dois.

## Se o build falhar

O erro mais provável é o nome do pacote `AmongUs.GameLibs.Steam` (ou sua
versão) ter mudado — a comunidade atualiza esses pacotes conforme o jogo
recebe updates. Se isso acontecer, procure o repositório **ExampleMod** do
MiraAPI no GitHub e copie o nome/fonte do pacote de lá para o
`SafeRoomMod.csproj`.
