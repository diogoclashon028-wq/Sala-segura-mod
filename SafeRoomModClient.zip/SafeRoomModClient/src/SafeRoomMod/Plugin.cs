using BepInEx;
using BepInEx.Unity.IL2CPP;
using HarmonyLib;
using MiraAPI.PluginLoading;
using Reactor;
using Reactor.Utilities;
using UnityEngine;

namespace SafeRoomMod;

// TODO: confira no Discord/repo do Reactor a versão de Among Us que está
// rodando e ajuste o [BepInProcess] / dependências se necessário.
[BepInAutoPlugin]
[BepInDependency(ReactorPlugin.Id)]
[BepInDependency(MiraApiPlugin.Id)]
public partial class SafeRoomPlugin : BasePlugin, IMiraPlugin
{
    public static SafeRoomPlugin Instance { get; private set; } = null!;

    public string OptionsTitleText => "Sala Segura";

    public override void Load()
    {
        Instance = this;

        var harmony = new Harmony(Id);
        harmony.PatchAll();

        Log.LogMessage("Sala Segura carregada (host-only).");
    }
}
