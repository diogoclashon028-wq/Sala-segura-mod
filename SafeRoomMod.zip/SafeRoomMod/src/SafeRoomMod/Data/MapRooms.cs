using Impostor.Api.Games;

namespace SafeRoomMod.Data;

/// <summary>
/// Tabela central: para cada mapa suportado, a lista de salas
/// disponíveis para escolha como "Sala Segura".
///
/// PREENCHA os valores de RoomZone com as coordenadas reais.
/// Os nomes das salas já estão corretos e são os que os
/// jogadores vão digitar no comando /sala.
/// </summary>
public static class MapRooms
{
    public static readonly Dictionary<MapTypes, RoomZone[]> Rooms = new()
    {
        [MapTypes.Skeld] = new[]
        {
            new RoomZone("Cafeteria",     -9f, -4f,  1f,  4f),
            new RoomZone("Weapons",        1f,  1f,  6f,  5f),
            new RoomZone("Navigation",     9f, -2f, 14f,  3f),
            new RoomZone("O2",              5f, -5f,  9f, -1f),
            new RoomZone("Shields",        9f, -7f, 13f, -3f),
            new RoomZone("Communications", 3f, -9f,  7f, -5f),
            new RoomZone("Storage",       -3f, -9f,  2f, -4f),
            new RoomZone("Admin",         -4f, -5f,  0f, -1f),
            new RoomZone("Electrical",    -8f, -3f, -4f,  1f),
            new RoomZone("LowerEngine",   -13f, -6f, -9f, -2f),
            new RoomZone("UpperEngine",   -13f,  2f, -9f,  6f),
            new RoomZone("Reactor",       -17f, -2f, -13f, 2f),
            new RoomZone("Security",      -9f,  1f, -6f,  4f),
            new RoomZone("MedBay",        -5f,  1f, -1f,  5f),
        },

        [MapTypes.MiraHQ] = new[]
        {
            new RoomZone("Cafeteria",      0f,  0f, 0f, 0f), // TODO
            new RoomZone("Balcony",        0f,  0f, 0f, 0f), // TODO
            new RoomZone("Launchpad",      0f,  0f, 0f, 0f), // TODO
            new RoomZone("Records",        0f,  0f, 0f, 0f), // TODO
            new RoomZone("Office",         0f,  0f, 0f, 0f), // TODO
            new RoomZone("Admin",          0f,  0f, 0f, 0f), // TODO
            new RoomZone("Storage",        0f,  0f, 0f, 0f), // TODO
            new RoomZone("Electrical",     0f,  0f, 0f, 0f), // TODO
            new RoomZone("Communications", 0f,  0f, 0f, 0f), // TODO
            new RoomZone("MedBay",         0f,  0f, 0f, 0f), // TODO
            new RoomZone("Decontamination",0f,  0f, 0f, 0f), // TODO
            new RoomZone("Laboratory",     0f,  0f, 0f, 0f), // TODO
            new RoomZone("Reactor",        0f,  0f, 0f, 0f), // TODO
        },

        [MapTypes.Polus] = new[]
        {
            new RoomZone("Office",         0f, 0f, 0f, 0f), // TODO
            new RoomZone("Admin",          0f, 0f, 0f, 0f), // TODO
            new RoomZone("Electrical",     0f, 0f, 0f, 0f), // TODO
            new RoomZone("O2",             0f, 0f, 0f, 0f), // TODO
            new RoomZone("Security",       0f, 0f, 0f, 0f), // TODO
            new RoomZone("Communications", 0f, 0f, 0f, 0f), // TODO
            new RoomZone("Weapons",        0f, 0f, 0f, 0f), // TODO
            new RoomZone("Specimens",      0f, 0f, 0f, 0f), // TODO
            new RoomZone("Laboratory",     0f, 0f, 0f, 0f), // TODO
            new RoomZone("Storage",        0f, 0f, 0f, 0f), // TODO
            new RoomZone("Dropship",       0f, 0f, 0f, 0f), // TODO
            new RoomZone("Decontamination",0f, 0f, 0f, 0f), // TODO
        },

        [MapTypes.Airship] = new[]
        {
            new RoomZone("MainHall",       0f, 0f, 0f, 0f), // TODO
            new RoomZone("Cockpit",        0f, 0f, 0f, 0f), // TODO
            new RoomZone("Kitchen",        0f, 0f, 0f, 0f), // TODO
            new RoomZone("Records",        0f, 0f, 0f, 0f), // TODO
            new RoomZone("Lounge",         0f, 0f, 0f, 0f), // TODO
            new RoomZone("Cargo",          0f, 0f, 0f, 0f), // TODO
            new RoomZone("Electrical",     0f, 0f, 0f, 0f), // TODO
            new RoomZone("Engine",         0f, 0f, 0f, 0f), // TODO
            new RoomZone("MeetingRoom",    0f, 0f, 0f, 0f), // TODO
            new RoomZone("Security",       0f, 0f, 0f, 0f), // TODO
            new RoomZone("Communications", 0f, 0f, 0f, 0f), // TODO
            new RoomZone("Armory",         0f, 0f, 0f, 0f), // TODO
            new RoomZone("GapRoom",        0f, 0f, 0f, 0f), // TODO
            new RoomZone("Showers",        0f, 0f, 0f, 0f), // TODO
            new RoomZone("Vault",          0f, 0f, 0f, 0f), // TODO
        },

        [MapTypes.Fungle] = new[]
        {
            new RoomZone("Camp",           0f, 0f, 0f, 0f), // TODO
            new RoomZone("SouthSnow",      0f, 0f, 0f, 0f), // TODO
            new RoomZone("Beach",          0f, 0f, 0f, 0f), // TODO
            new RoomZone("Volcano",        0f, 0f, 0f, 0f), // TODO
            new RoomZone("SmallCave",      0f, 0f, 0f, 0f), // TODO
            new RoomZone("Lily",           0f, 0f, 0f, 0f), // TODO
            new RoomZone("Boulder",        0f, 0f, 0f, 0f), // TODO
            new RoomZone("Dig",            0f, 0f, 0f, 0f), // TODO
            new RoomZone("Kiosk",          0f, 0f, 0f, 0f), // TODO
            new RoomZone("Cave",           0f, 0f, 0f, 0f), // TODO
        },
    };

    public static RoomZone[] GetRoomsForMap(MapTypes map)
    {
        return Rooms.TryGetValue(map, out var rooms) ? rooms : Array.Empty<RoomZone>();
    }

    public static RoomZone? FindRoom(MapTypes map, string roomName)
    {
        var rooms = GetRoomsForMap(map);
        foreach (var room in rooms)
        {
            if (string.Equals(room.Name, roomName, StringComparison.OrdinalIgnoreCase))
            {
                return room;
            }
        }
        return null;
    }
}
