using System.Collections.Generic;

namespace SafeRoomMod.Data;

/// <summary>
/// Salas disponíveis por mapa. Os valores de MapId seguem o enum interno do
/// jogo (ShipStatus.MapType): 0 = Skeld, 1 = MiraHQ, 2 = Polus, 3 = Airship,
/// 4 = Fungle.
///
/// TODO (pendente, igual no projeto anterior): só o Skeld tem coordenadas de
/// exemplo preenchidas. Os outros mapas estão com placeholders (0,0,0,0) e
/// precisam ser preenchidos com coordenadas reais. Formas de conseguir isso:
///   1. Rodar o jogo com o mod carregado e logar Player.transform.position
///      enquanto anda pelas salas (mais confiável).
///   2. Olhar mods open-source como TownOfHost / TOU-Mira que já têm listas
///      de salas por mapa.
/// </summary>
public static class MapRooms
{
    public static readonly Dictionary<byte, List<RoomZone>> Rooms = new()
    {
        [0] = new List<RoomZone> // Skeld (exemplo preenchido)
        {
            new("Cafeteria", -3f, 3f, 5f, 9f),
            new("Weapons", 6f, 4f, 10f, 8f),
            new("Navigation", 12f, 1f, 16f, 5f),
            new("Shields", 10f, -6f, 15f, -2f),
            new("Communications", 2f, -10f, 7f, -6f),
            new("Storage", -2f, -9f, 3f, -4f),
            new("Electrical", -8f, -6f, -3f, -2f),
            new("Medbay", -9f, 1f, -4f, 5f),
            new("Security", -12f, -2f, -8f, 1f),
            new("Reactor", -18f, -3f, -13f, 2f),
            new("Upper Engine", -14f, 3f, -10f, 7f),
            new("Lower Engine", -14f, -8f, -10f, -4f),
            new("Admin", -1f, -2f, 3f, 1f),
        },

        [1] = new List<RoomZone> // MiraHQ — TODO: preencher coordenadas reais
        {
            new("Cafeteria", 0f, 0f, 0f, 0f),
            new("Balcony", 0f, 0f, 0f, 0f),
            new("Reactor", 0f, 0f, 0f, 0f),
            new("Medbay", 0f, 0f, 0f, 0f),
            new("Admin", 0f, 0f, 0f, 0f),
            new("Storage", 0f, 0f, 0f, 0f),
            new("Office", 0f, 0f, 0f, 0f),
            new("Communications", 0f, 0f, 0f, 0f),
            new("Greenhouse", 0f, 0f, 0f, 0f),
            new("Launchpad", 0f, 0f, 0f, 0f),
            new("Decontamination", 0f, 0f, 0f, 0f),
            new("Laboratory", 0f, 0f, 0f, 0f),
            new("Locker Room", 0f, 0f, 0f, 0f),
        },

        [2] = new List<RoomZone> // Polus — TODO: preencher coordenadas reais
        {
            new("Office", 0f, 0f, 0f, 0f),
            new("Admin", 0f, 0f, 0f, 0f),
            new("Electrical", 0f, 0f, 0f, 0f),
            new("O2", 0f, 0f, 0f, 0f),
            new("Security", 0f, 0f, 0f, 0f),
            new("Communications", 0f, 0f, 0f, 0f),
            new("Weapons", 0f, 0f, 0f, 0f),
            new("Specimen Room", 0f, 0f, 0f, 0f),
            new("Dropship", 0f, 0f, 0f, 0f),
            new("Decontamination", 0f, 0f, 0f, 0f),
            new("Laboratory", 0f, 0f, 0f, 0f),
            new("Storage", 0f, 0f, 0f, 0f),
        },

        [3] = new List<RoomZone> // Airship — TODO: preencher coordenadas reais
        {
            new("Main Hall", 0f, 0f, 0f, 0f),
            new("Cockpit", 0f, 0f, 0f, 0f),
            new("Kitchen", 0f, 0f, 0f, 0f),
            new("Records", 0f, 0f, 0f, 0f),
            new("Security", 0f, 0f, 0f, 0f),
            new("Electrical", 0f, 0f, 0f, 0f),
            new("Engine", 0f, 0f, 0f, 0f),
            new("Cargo Bay", 0f, 0f, 0f, 0f),
            new("Vault", 0f, 0f, 0f, 0f),
            new("Communications", 0f, 0f, 0f, 0f),
            new("Meeting Room", 0f, 0f, 0f, 0f),
            new("Showers", 0f, 0f, 0f, 0f),
            new("Armory", 0f, 0f, 0f, 0f),
            new("Gap Room", 0f, 0f, 0f, 0f),
        },

        [4] = new List<RoomZone> // Fungle — TODO: preencher coordenadas reais
        {
            new("Camp", 0f, 0f, 0f, 0f),
            new("Volcano", 0f, 0f, 0f, 0f),
            new("Beach", 0f, 0f, 0f, 0f),
            new("Cave", 0f, 0f, 0f, 0f),
            new("Ruins", 0f, 0f, 0f, 0f),
            new("Lookout", 0f, 0f, 0f, 0f),
            new("Cabins", 0f, 0f, 0f, 0f),
            new("Storage", 0f, 0f, 0f, 0f),
            new("Dr. Fungle's House", 0f, 0f, 0f, 0f),
            new("Med Bay", 0f, 0f, 0f, 0f),
        },
    };
}
