using System.Collections.Generic;
using SafeRoomMod.Data;

namespace SafeRoomMod;

/// <summary>
/// Guarda, em memória (no cliente do host), qual sala cada jogador escolheu
/// como "sala segura" nesta partida. Como o mod é host-only, essa é a fonte
/// de verdade única: o host decide quem está imune, os outros jogadores
/// (mesmo sem o mod) só sentem o efeito (o kill simplesmente não acontece).
/// </summary>
public static class SafeRoomManager
{
    // playerId -> sala escolhida
    private static readonly Dictionary<byte, RoomZone> ClaimedRooms = new();

    public static bool SelectionPhaseOpen { get; set; }

    public static void Reset()
    {
        ClaimedRooms.Clear();
        SelectionPhaseOpen = false;
    }

    public static bool TryClaim(byte playerId, RoomZone room)
    {
        if (!SelectionPhaseOpen)
        {
            return false;
        }

        ClaimedRooms[playerId] = room;
        return true;
    }

    public static bool HasClaimed(byte playerId)
    {
        return ClaimedRooms.ContainsKey(playerId);
    }

    public static bool IsPlayerSafe(byte playerId, float x, float y)
    {
        if (!ClaimedRooms.TryGetValue(playerId, out var room))
        {
            return false;
        }

        return room.Contains(x, y);
    }
}
