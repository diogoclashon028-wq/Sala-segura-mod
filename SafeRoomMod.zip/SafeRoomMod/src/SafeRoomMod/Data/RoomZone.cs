namespace SafeRoomMod.Data;

/// <summary>
/// Representa a área retangular (em coordenadas do mundo do jogo)
/// que define uma sala em um mapa. Among Us usa um sistema de
/// coordenadas em unidades de jogo (não pixels), com origem
/// geralmente próxima ao centro do mapa.
///
/// IMPORTANTE: Os valores abaixo são um ESQUELETO/placeholder.
/// Você precisa substituir pelas coordenadas reais de cada sala.
/// Fontes recomendadas para extrair essas coordenadas:
///   - Repositórios open-source de mods como TownOfHost / Rolesmith
///     (procure por "RoomArea", "MapRoom" ou "PlainShipRoom" no
///     código-fonte deles no GitHub).
///   - Extração manual: logar a posição (x,y) do jogador enquanto
///     ele caminha pelas bordas de cada sala, usando um plugin de
///     debug simples no seu próprio servidor.
/// </summary>
public readonly struct RoomZone
{
    public string Name { get; }
    public float MinX { get; }
    public float MinY { get; }
    public float MaxX { get; }
    public float MaxY { get; }

    public RoomZone(string name, float minX, float minY, float maxX, float maxY)
    {
        Name = name;
        MinX = minX;
        MinY = minY;
        MaxX = maxX;
        MaxY = maxY;
    }

    public bool Contains(float x, float y)
    {
        return x >= MinX && x <= MaxX && y >= MinY && y <= MaxY;
    }
}
